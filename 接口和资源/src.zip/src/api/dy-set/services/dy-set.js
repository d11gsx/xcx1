'use strict';

/**
 * dy-set service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::dy-set.dy-set');
