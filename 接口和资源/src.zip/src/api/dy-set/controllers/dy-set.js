'use strict';

/**
 * dy-set controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::dy-set.dy-set');
