'use strict';

/**
 * red-envelope controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::red-envelope.red-envelope');
