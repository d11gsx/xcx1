'use strict';

/**
 * brush-question service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::brush-question.brush-question');
