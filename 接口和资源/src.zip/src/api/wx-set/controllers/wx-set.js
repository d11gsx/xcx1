'use strict';

/**
 * wx-set controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::wx-set.wx-set');
