'use strict';

/**
 * wx-set service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::wx-set.wx-set');
