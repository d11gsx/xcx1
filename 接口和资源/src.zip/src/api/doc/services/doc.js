'use strict';

/**
 * doc service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::doc.doc');
