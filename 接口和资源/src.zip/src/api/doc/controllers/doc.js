'use strict';

/**
 * doc controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::doc.doc');
