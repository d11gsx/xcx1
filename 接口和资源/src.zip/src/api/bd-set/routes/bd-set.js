'use strict';

/**
 * bd-set router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::bd-set.bd-set');
