'use strict';

/**
 * bd-set controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bd-set.bd-set');
