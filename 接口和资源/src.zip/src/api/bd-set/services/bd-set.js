'use strict';

/**
 * bd-set service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::bd-set.bd-set');
